Edit the style.css file to your liking.
